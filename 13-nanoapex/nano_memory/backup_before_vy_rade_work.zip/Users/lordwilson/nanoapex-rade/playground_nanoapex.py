def boring_function():
    print("I am ignored")

def special_function():
    # @nanoapex: optimize me
    print("I will be picked up by RADE")
