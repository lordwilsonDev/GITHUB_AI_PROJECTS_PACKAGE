# RADE - Real-time AST Development Engine

A background Python daemon that watches for code changes and provides intelligent code improvements through AST analysis.

## Overview

RADE works as a background service that:
- Monitors Python files for changes using file system events
- Parses code into Abstract Syntax Trees (AST) using tree-sitter
- Routes events for potential code improvements
- Integrates with MoIE (Model of Intelligent Enhancement) for suggestions

## Architecture

```
Vy (editor) → file save → RADE (watcher) → MoIE (improvements) → surgical patches
```

## Files

- `rade_engine.py` - Core file watcher and AST parser
- `event_router.py` - Event routing system (placeholder)
- `README.md` - This documentation

## Usage

1. Navigate to the project directory:
   ```bash
   cd ~/nanoapex-rade
   ```

2. Install dependencies:
   ```bash
   pip install watchdog tree-sitter tree-sitter-python
   ```

3. Start RADE:
   ```bash
   python3 rade_engine.py
   ```

4. Edit any Python file in the directory to see RADE detect changes

## Safety Features

- Only monitors its own directory (`~/nanoapex-rade`)
- No system file modifications
- Clean sandbox environment
- Easy to stop with Ctrl+C

## Next Development Steps

Choose your next enhancement:
- **A) Task Routing** - Forward AST nodes to MoIE
- **B) Surgical Splicing** - Structural code editing
- **C) Event Types** - Detect class/function creation
- **D) MoIE Call Stub** - Mock code improvement suggestions

## Status

✅ Core file watcher implemented
✅ AST parsing with tree-sitter
✅ Safe sandbox environment
🚧 Event routing (placeholder)
🚧 MoIE integration (pending)
🚧 Code improvement engine (pending)
